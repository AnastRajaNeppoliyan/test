  import { Component } from '@angular/core';
  import { CommonModule } from '@angular/common';
  import { MatIconModule } from '@angular/material/icon';


  @Component({
    selector: 'app-grid',
    standalone: true,
    imports: [CommonModule, MatIconModule],
    templateUrl: './grid.component.html',
    styleUrls: ['./grid.component.css'],
  })
  export class GridComponent {
    roomId: string = 'room1'; 
    activeSocketId:string='socket2';
    roomStreams: { [roomId: string]: { socketId: string; stream: string }[] } = {
      room1: [
        { socketId: 'socket1', stream: 'mediaStream1' },
        { socketId: 'socket2', stream: 'mediaStream2' },
        { socketId: 'socket3', stream: 'mediaStream3' },
        { socketId: 'socket4', stream: 'mediaStream4' },
       
      ],
    };


      videoStatuses: { [socketId: string]: { status: boolean; userName: string } } = {
        socket1: { status: true, userName: 'User1' },
        socket2: { status: true, userName: 'User2' },
        socket3: { status: true, userName: 'User3' },
        socket4: { status: true, userName: 'User4' },
      };


    audioStatuses: { [socketId: string]: { status: boolean } } = {
      socket1: { status: true },
      socket2: { status: false },
      socket3: { status: true },
      socket4: { status: false },
    };

    
    get safeRoomStreams() {
      return this.roomStreams[this.roomId] || [];
    }


    toggleFullScreenVid(videoId: string): void {
      console.log(`Toggling fullscreen for video with ID: ${videoId}`);
    }
  }
